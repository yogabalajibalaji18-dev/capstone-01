import React, { useState, useEffect } from 'react';
import { Navbar, TabType } from './components/Navbar';
import { UploadZone } from './components/UploadZone';
import { DocumentViewer } from './components/DocumentViewer';
import { RecognitionEditor } from './components/RecognitionEditor';
import { SmartSearchPanel } from './components/SmartSearchPanel';
import { SummarizerPanel } from './components/SummarizerPanel';
import { ModelLab } from './components/ModelLab';
import { TestRunnerModal } from './components/TestRunnerModal';
import { DocumentResult, SupportedLanguage, SearchMatch, BoundingBox } from './types/htr';
import { SAMPLE_DOCUMENTS, generateHandwrittenSample, SampleDocument } from './data/samples';
import { normalizeNFC } from './lib/unicodeUtils';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('htr');
  const [documents, setDocuments] = useState<DocumentResult[]>([]);
  const [activeDocumentId, setActiveDocumentId] = useState<string | null>(null);
  const [selectedLineId, setSelectedLineId] = useState<string | null>(null);
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const [highlightBoxes, setHighlightBoxes] = useState<BoundingBox[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<SupportedLanguage>('auto');
  const [hasGemini, setHasGemini] = useState(false);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [searchInitialQuery, setSearchInitialQuery] = useState('');

  // Current active document
  const activeDocument = documents.find((d) => d.id === activeDocumentId) || documents[0] || null;

  const loadSampleDocument = (sample: SampleDocument, isInitial = false) => {
    const { dataUrl, lines } = generateHandwrittenSample(sample);
    const avgConfidence = Number(
      (lines.reduce((a, b) => a + b.confidence, 0) / lines.length).toFixed(3)
    );
    const fullText = lines.map((l) => l.text).join('\n');

    const newDoc: DocumentResult = {
      id: `doc-${sample.id}`,
      name: `${sample.title}.png`,
      imageUrl: dataUrl,
      width: 1100,
      height: 900,
      language: sample.language,
      detectedScript: sample.language,
      scriptConfidence: 0.98,
      lines,
      fullText,
      averageConfidence: avgConfidence,
      processingTimeMs: 145,
      timestamp: new Date().toISOString(),
    };

    setDocuments((prev) => [newDoc, ...prev.filter((d) => d.id !== newDoc.id)]);
    setActiveDocumentId(newDoc.id);
    setSelectedLineId(newDoc.lines[0]?.id || null);
    setSelectedWordId(null);
    setHighlightBoxes([]);
    setSelectedLanguage(sample.language);
    if (!isInitial) {
      setActiveTab('htr');
    }
  };

  // On mount: check server status and load initial sample
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setHasGemini(Boolean(data.hasGeminiKey));
      })
      .catch(() => {});

    // Preload Tamil historical sample with pixel-measured bboxes
    const defaultSample = SAMPLE_DOCUMENTS[1]; // Tamil sample
    loadSampleDocument(defaultSample, true);
  }, []);

  const processImage = async (
    imageBase64: string,
    language: SupportedLanguage,
    fileName: string,
    isInitial = false
  ) => {
    setIsProcessing(true);
    try {
      const response = await fetch('/api/ocr/recognize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          language,
          fileName,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const result = await response.json();
      const enrichedResult: DocumentResult = {
        ...result,
        imageUrl: imageBase64,
        width: 1100,
        height: 900,
      };

      setDocuments((prev) => [enrichedResult, ...prev.filter((d) => d.id !== enrichedResult.id)]);
      setActiveDocumentId(enrichedResult.id);
      setSelectedLineId(enrichedResult.lines[0]?.id || null);
      setSelectedWordId(null);
      setHighlightBoxes([]);

      if (!isInitial) {
        setActiveTab('htr');
      }
    } catch (err) {
      console.error('OCR processing error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUpdateLineText = (lineId: string, newText: string) => {
    if (!activeDocument) return;

    const updatedLines = activeDocument.lines.map((line) => {
      if (line.id === lineId) {
        return {
          ...line,
          text: normalizeNFC(newText),
        };
      }
      return line;
    });

    const updatedFullText = updatedLines.map((l) => l.text).join('\n');

    const updatedDoc: DocumentResult = {
      ...activeDocument,
      lines: updatedLines,
      fullText: updatedFullText,
    };

    setDocuments((prev) => prev.map((d) => (d.id === updatedDoc.id ? updatedDoc : d)));
  };

  const handleSelectSearchMatch = (match: SearchMatch) => {
    setActiveDocumentId(match.docId);
    setSelectedLineId(match.lineId);
    setSelectedWordId(match.wordId || null);
    setHighlightBoxes([match.bbox]);
    setActiveTab('htr');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        documentCount={documents.length}
        hasGemini={hasGemini}
        onOpenTestModal={() => setIsTestModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Upload Zone & Presets is visible in HTR tab or when no document exists */}
        {activeTab === 'htr' && (
          <UploadZone
            onProcessImage={(base64, lang, name) => processImage(base64, lang, name)}
            onSelectPresetSample={(sample) => loadSampleDocument(sample)}
            isProcessing={isProcessing}
            selectedLanguage={selectedLanguage}
            setSelectedLanguage={setSelectedLanguage}
          />
        )}

        {/* Tab 1: HTR Studio (Canvas & Editor) */}
        {activeTab === 'htr' && activeDocument && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Visual Canvas Viewport */}
            <div className="lg:col-span-7 h-[680px]">
              <DocumentViewer
                document={activeDocument}
                selectedLineId={selectedLineId}
                selectedWordId={selectedWordId}
                onSelectLine={(lId) => {
                  setSelectedLineId(lId);
                  setSelectedWordId(null);
                }}
                onSelectWord={(wId, lId) => {
                  setSelectedWordId(wId);
                  setSelectedLineId(lId);
                }}
                highlightBoxes={highlightBoxes}
              />
            </div>

            {/* Synchronized Transcription & Spell-Check Editor */}
            <div className="lg:col-span-5 h-[680px]">
              <RecognitionEditor
                document={activeDocument}
                selectedLineId={selectedLineId}
                selectedWordId={selectedWordId}
                onSelectLine={(lId) => {
                  setSelectedLineId(lId);
                  setSelectedWordId(null);
                }}
                onSelectWord={(wId, lId) => {
                  setSelectedWordId(wId);
                  setSelectedLineId(lId);
                }}
                onUpdateLineText={handleUpdateLineText}
                onNavigateToSearch={(q) => {
                  if (q) setSearchInitialQuery(q);
                  setActiveTab('search');
                }}
                onNavigateToSummary={() => setActiveTab('summary')}
              />
            </div>
          </div>
        )}

        {/* Tab 2: Smart Search */}
        {activeTab === 'search' && (
          <SmartSearchPanel
            documents={documents}
            onSelectMatch={handleSelectSearchMatch}
            initialQuery={searchInitialQuery}
          />
        )}

        {/* Tab 3: Automatic Summarizer */}
        {activeTab === 'summary' && (
          <SummarizerPanel
            document={activeDocument}
            documents={documents}
            onSelectDocument={(doc) => setActiveDocumentId(doc.id)}
          />
        )}

        {/* Tab 4: Model Lab & Charsets */}
        {activeTab === 'models' && <ModelLab />}
      </main>

      {/* CI/CD Test Runner Modal */}
      <TestRunnerModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
      />
    </div>
  );
}
