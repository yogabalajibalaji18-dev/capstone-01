import { SupportedLanguage, LinePrediction, WordPrediction } from '../types/htr';
import { suggestCorrection } from '../lib/dictionaries';
import { normalizeNFC } from '../lib/unicodeUtils';

export interface SampleDocument {
  id: string;
  title: string;
  language: SupportedLanguage;
  scriptBadge: string;
  description: string;
  source: string;
  lines: string[];
}

export const SAMPLE_DOCUMENTS: SampleDocument[] = [
  {
    id: 'sample-en-1',
    title: 'English: IAM Machine Learning Research Notes',
    language: 'en',
    scriptBadge: 'Latin Script',
    description: 'Cursive handwritten lab notes discussing CTC loss and Bidirectional LSTM recurrent layers.',
    source: 'IAM Handwriting Database partition',
    lines: [
      'Handwritten text recognition with deep neural networks.',
      'Feature extraction uses multi-scale convolutional residual layers.',
      'Bidirectional LSTM models sequential character context.',
      'CTC loss enables end-to-end alignment without manual labels.',
      'Language model beam search improves transcription accuracy.',
      'Experiments demonstrate robust performance across cursive variations.',
    ],
  },
  {
    id: 'sample-ta-1',
    title: 'Tamil: வரலாற்று கையெழுத்துப் பிரதி (Tamil Manuscript)',
    language: 'ta',
    scriptBadge: 'தமிழ் எழுத்துமுறை (Tamil Script)',
    description: 'Tamil cursive handwriting excerpt discussing classical literature and education.',
    source: 'Tamil Palm Leaf & Modern Script Archive',
    lines: [
      'வணக்கம்! கல்வி சிறந்த தமிழ்நாடு என்று பாரதி பாடினார்.',
      'பண்டைய சுவடிகளில் உள்ள தமிழ் கையெழுத்துக்களை வாசிப்பது அரிய கலை.',
      'திருக்குறள் உலகப் பொதுமறையாக மனித குலத்திற்கு வழிகாட்டுகிறது.',
      'நவீன கணிப்பொறி வழியே தமிழ் எழுத்துக்களை பகுப்பாய்வு செய்கிறோம்.',
      'மொழி வளர்ச்சிக்கு புதிய தொழில்நுட்பங்கள் பெரிதும் உதவுகின்றன.',
      'கையெழுத்துப் படங்களை பாதுகாத்து மின்னுருவாக்கம் செய்வோம்.',
    ],
  },
  {
    id: 'sample-hi-1',
    title: 'Hindi: हस्तलिखित वैज्ञानिक पांडुलिपि (Devanagari Notes)',
    language: 'hi',
    scriptBadge: 'देवनागरी लिपि (Devanagari Script)',
    description: 'Devanagari handwritten prose notes on knowledge, perseverance, and machine learning.',
    source: 'Hindi Handwritten Document Repository',
    lines: [
      'नमस्ते भारत! विद्या ददाति विनयं विनयाद्याति पात्रताम्।',
      'परिश्रम ही सफलता की असली कुंजी है जो मार्ग प्रशस्त करती है।',
      'भारतीय भाषाओं में हस्तलेख पहचान एक अत्यंत महत्वपूर्ण क्षेत्र है।',
      'कंप्यूटर विज्ञान और कृत्रिम बुद्धिमत्ता का समन्वय नई दिशा दे रहा है।',
      'प्राचीन पांडुलिपियों का डिजिटलीकरण हमारी सांस्कृतिक धरोहर को सहेजता है।',
      'सतत अध्ययन एवं अनुसंधान से ही ज्ञान की वृद्धि संभव होती है।',
    ],
  },
  {
    id: 'sample-ml-1',
    title: 'Malayalam: കൈയെഴുത്തു രേഖകൾ (Malayalam Script Document)',
    language: 'ml',
    scriptBadge: 'മലയാള ലിപി (Malayalam Script)',
    description: 'Malayalam cursive literary manuscript noting the heritage and digital preservation of Kerala scripts.',
    source: 'Malayalam Heritage Script Project',
    lines: [
      'നമസ്കാരം! മലയാളം നമ്മുടെ പ്രിയപ്പെട്ട മാതൃഭാഷയാണ്.',
      'കേരളം പ്രകൃതിഭംഗിയും സമ്പന്നമായ സാംസ്കാരിക പൈതൃകവുമുള്ള നാടാണ്.',
      'പഴയ താളിയോല രേഖകളിലെ അക്ഷരങ്ങൾ തിരിച്ചറിയുന്നത് വെല്ലുവിളിയാണ്.',
      'ആധുനിക സാങ്കേതികവിദ്യ ഉപയോഗിച്ച് മലയാള രേഖകൾ ഡിജിറ്റൈസ് ചെയ്യുന്നു.',
      'വായനയും അറിവും മനുഷ്യനെ കൂടുതൽ ഉന്നതനാക്കുന്നു.',
      'പുതിയ തലമുറയ്ക്കായി നമ്മുടെ സാഹിത്യ സമ്പത്ത് സംരക്ഷിക്കേണ്ടതുണ്ട്.',
    ],
  },
];

/**
 * Generates an authentic canvas-based handwritten document image with ruled lines,
 * and calculates PIXEL-PERFECT word bounding boxes using ctx.measureText.
 */
export function generateHandwrittenSample(sample: SampleDocument): {
  dataUrl: string;
  lines: LinePrediction[];
} {
  const canvas = document.createElement('canvas');
  const width = 1100;
  const height = 900;
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return { dataUrl: '', lines: [] };

  // 1. Paper Background (Warm textured aged paper)
  const bgGrad = ctx.createLinearGradient(0, 0, width, height);
  bgGrad.addColorStop(0, '#fbf8ee');
  bgGrad.addColorStop(0.5, '#f7f3e4');
  bgGrad.addColorStop(1, '#f3edd6');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Subtle paper grain noise
  ctx.fillStyle = 'rgba(120, 100, 80, 0.025)';
  for (let i = 0; i < 4500; i++) {
    const rx = Math.random() * width;
    const ry = Math.random() * height;
    ctx.fillRect(rx, ry, 2, 2);
  }

  // 2. Ruled lines & margins
  const marginLeft = 110;
  const lineSpacing = 72;
  const startY = 160;

  // Red vertical margin rule
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(marginLeft, 50);
  ctx.lineTo(marginLeft, height - 50);
  ctx.stroke();

  // Subtle blue horizontal ruled lines
  ctx.strokeStyle = 'rgba(99, 130, 190, 0.25)';
  ctx.lineWidth = 1.2;
  for (let y = startY; y < height - 60; y += lineSpacing) {
    ctx.beginPath();
    ctx.moveTo(40, y);
    ctx.lineTo(width - 40, y);
    ctx.stroke();
  }

  // 3. Document Title / Header
  ctx.font = '600 18px "Inter", sans-serif';
  ctx.fillStyle = '#64748b';
  ctx.fillText(`HTR Dataset: ${sample.title}`, marginLeft + 10, 90);

  ctx.font = '400 13px "Inter", sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText(`Script: ${sample.scriptBadge} • Source: ${sample.source}`, marginLeft + 10, 115);

  // 4. Handwritten text lines
  const fontFamilies: Record<SupportedLanguage, string> = {
    auto: '"Inter", sans-serif',
    en: '"Inter", "Caveat", sans-serif',
    ta: '"Noto Sans Tamil", sans-serif',
    hi: '"Noto Sans Devanagari", sans-serif',
    ml: '"Noto Sans Malayalam", sans-serif',
  };

  const selectedFont = fontFamilies[sample.language] || fontFamilies.en;
  ctx.font = `500 27px ${selectedFont}`;

  const lines: LinePrediction[] = [];

  sample.lines.forEach((lineText, idx) => {
    const y = startY + (idx + 1) * lineSpacing - 18;
    const x = marginLeft + 35 + (idx % 2 === 0 ? 0 : 5); // subtle slant offset

    // Draw ink text line
    ctx.fillStyle = idx % 2 === 0 ? '#1e293b' : '#0f172a';
    ctx.fillText(lineText, x, y);

    // Calculate EXACT bounding box for every word using ctx.measureText
    const wordsRaw = lineText.split(/\s+/).filter(Boolean);
    const spaceWidth = ctx.measureText(' ').width;
    let currentX = x;

    const lineYmin = Number((((y - 32) / height) * 100).toFixed(2));
    const lineYmax = Number((((y + 14) / height) * 100).toFixed(2));

    const words: WordPrediction[] = [];

    wordsRaw.forEach((w, wIdx) => {
      const wordWidth = ctx.measureText(w).width;
      const xmin = Number(((currentX / width) * 100).toFixed(2));
      const xmax = Number((((currentX + wordWidth) / width) * 100).toFixed(2));

      // Realistic confidence
      const conf = Number((0.92 + (wIdx % 3) * 0.03).toFixed(2));
      const check = suggestCorrection(w, sample.language as any);

      words.push({
        id: `w-${idx}-${wIdx}`,
        text: normalizeNFC(w),
        confidence: conf,
        bbox: {
          ymin: lineYmin,
          xmin,
          ymax: lineYmax,
          xmax,
        },
        alternatives: [w + 's', w.slice(0, -1)],
        suggestedCorrection: check.suggestion && check.suggestion !== w.toLowerCase() ? check.suggestion : undefined,
        script: sample.language,
      });

      // advance X by word width and space
      currentX += wordWidth + spaceWidth;
    });

    const lineXmin = Number(((x / width) * 100).toFixed(2));
    const lineXmax = Number((((currentX) / width) * 100).toFixed(2));
    const lineConf = Number((words.reduce((a, b) => a + b.confidence, 0) / words.length).toFixed(3));

    lines.push({
      id: `line-${idx}`,
      lineNumber: idx + 1,
      text: normalizeNFC(lineText),
      confidence: lineConf,
      bbox: {
        ymin: lineYmin,
        xmin: lineXmin,
        ymax: lineYmax,
        xmax: lineXmax,
      },
      script: sample.language,
      words,
    });
  });

  return {
    dataUrl: canvas.toDataURL('image/png'),
    lines,
  };
}

export function generateHandwrittenCanvas(sample: SampleDocument): string {
  return generateHandwrittenSample(sample).dataUrl;
}
