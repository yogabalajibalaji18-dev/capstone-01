export type SupportedLanguage = 'auto' | 'en' | 'ta' | 'hi' | 'ml';

export interface BoundingBox {
  ymin: number; // 0 - 100 percentage or normalized 0 - 1000
  xmin: number;
  ymax: number;
  xmax: number;
}

export interface WordPrediction {
  id: string;
  text: string;
  confidence: number; // 0.0 - 1.0
  bbox: BoundingBox;
  alternatives?: string[];
  suggestedCorrection?: string;
  script?: string;
}

export interface LinePrediction {
  id: string;
  lineNumber: number;
  text: string;
  confidence: number;
  bbox: BoundingBox;
  script: string;
  words: WordPrediction[];
}

export interface DocumentResult {
  id: string;
  name: string;
  imageUrl: string;
  width: number;
  height: number;
  language: SupportedLanguage;
  detectedScript: string;
  scriptConfidence: number;
  lines: LinePrediction[];
  fullText: string;
  averageConfidence: number;
  processingTimeMs: number;
  timestamp: string;
}

export interface SearchMatch {
  docId: string;
  docName: string;
  lineId: string;
  lineNumber: number;
  wordId?: string;
  lineText: string;
  matchedWord: string;
  similarity: number;
  bbox: BoundingBox;
  snippet: string;
  matchIndices: [number, number];
}

export interface SummaryResult {
  type: 'extractive' | 'abstractive';
  summary: string;
  bullets: string[];
  keyEntities: string[];
  compressionRatio: number;
  rawWordCount: number;
  summaryWordCount: number;
  modelUsed: string;
}

export interface CharsetInfo {
  lang: SupportedLanguage;
  name: string;
  nativeName: string;
  unicodeRange: string;
  characters: string[];
  vowels: string[];
  consonants: string[];
  modelPath: string;
  totalChars: number;
  samplePhrase: string;
}

export interface SystemTestResult {
  testName: string;
  category: 'unit' | 'integration' | 'system';
  passed: boolean;
  executionTimeMs: number;
  details: string;
}
