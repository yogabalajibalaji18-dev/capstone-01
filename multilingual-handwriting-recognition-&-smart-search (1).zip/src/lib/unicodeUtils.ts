/**
 * Unicode normalization and script detection utilities
 * Supports: English (Latin), Tamil (U+0B80–0BFF), Devanagari/Hindi (U+0900–097F), Malayalam (U+0D00–0D7F)
 */

export function normalizeNFC(text: string): string {
  if (!text) return '';
  return text.normalize('NFC').trim();
}

export type ScriptName = 'latin' | 'tamil' | 'devanagari' | 'malayalam' | 'common' | 'unknown';

export function getCharScript(char: string): ScriptName {
  const code = char.codePointAt(0);
  if (code === undefined) return 'unknown';

  // Basic Latin & Latin-1 Supplement
  if ((code >= 0x0041 && code <= 0x005a) || (code >= 0x0061 && code <= 0x007a) || (code >= 0x00c0 && code <= 0x024f)) {
    return 'latin';
  }

  // Devanagari (Hindi, Sanskrit, Marathi)
  if (code >= 0x0900 && code <= 0x097f) {
    return 'devanagari';
  }

  // Tamil
  if (code >= 0x0b80 && code <= 0x0bff) {
    return 'tamil';
  }

  // Malayalam
  if (code >= 0x0d00 && code <= 0x0d7f) {
    return 'malayalam';
  }

  // Common digits, punctuation, whitespace
  if (
    (code >= 0x0020 && code <= 0x0040) ||
    (code >= 0x005b && code <= 0x0060) ||
    (code >= 0x007b && code <= 0x007e) ||
    (code >= 0x2000 && code <= 0x206f)
  ) {
    return 'common';
  }

  return 'unknown';
}

export function detectScript(text: string): {
  dominantScript: 'en' | 'ta' | 'hi' | 'ml';
  scriptName: string;
  confidence: number;
  distribution: Record<string, number>;
} {
  const normalized = normalizeNFC(text);
  const counts: Record<string, number> = {
    latin: 0,
    tamil: 0,
    devanagari: 0,
    malayalam: 0,
  };

  let totalIndicOrLatin = 0;

  for (const char of normalized) {
    const s = getCharScript(char);
    if (s in counts) {
      counts[s]++;
      totalIndicOrLatin++;
    }
  }

  if (totalIndicOrLatin === 0) {
    return {
      dominantScript: 'en',
      scriptName: 'Latin / English',
      confidence: 1.0,
      distribution: { en: 1, ta: 0, hi: 0, ml: 0 },
    };
  }

  let maxScript = 'latin';
  let maxCount = -1;

  for (const [script, count] of Object.entries(counts)) {
    if (count > maxCount) {
      maxCount = count;
      maxScript = script;
    }
  }

  const confidence = Math.min(1.0, Number((maxCount / totalIndicOrLatin).toFixed(3)));

  const mapToLang: Record<string, 'en' | 'ta' | 'hi' | 'ml'> = {
    latin: 'en',
    tamil: 'ta',
    devanagari: 'hi',
    malayalam: 'ml',
  };

  const nameMap: Record<string, string> = {
    latin: 'English (Latin)',
    tamil: 'Tamil (தமிழ்)',
    devanagari: 'Hindi (देवनागरी)',
    malayalam: 'Malayalam (മലയാളം)',
  };

  return {
    dominantScript: mapToLang[maxScript] || 'en',
    scriptName: nameMap[maxScript] || 'English (Latin)',
    confidence,
    distribution: {
      en: Number((counts.latin / totalIndicOrLatin).toFixed(3)),
      ta: Number((counts.tamil / totalIndicOrLatin).toFixed(3)),
      hi: Number((counts.devanagari / totalIndicOrLatin).toFixed(3)),
      ml: Number((counts.malayalam / totalIndicOrLatin).toFixed(3)),
    },
  };
}

export function isValidScriptString(text: string, lang: 'en' | 'ta' | 'hi' | 'ml'): boolean {
  if (!text) return true;
  const script = detectScript(text);
  return script.dominantScript === lang || script.confidence < 0.6;
}
