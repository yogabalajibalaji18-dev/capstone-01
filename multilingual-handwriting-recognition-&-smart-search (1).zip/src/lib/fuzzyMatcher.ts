/**
 * RapidFuzz / Levenshtein fuzzy matching engine for Smart Search in HTR
 * Tolerates OCR substitutions, character misrecognitions, and partial words.
 */

import { normalizeNFC } from './unicodeUtils';

export function levenshteinDistance(s1: string, s2: string): number {
  const m = s1.length;
  const n = s2.length;
  if (m === 0) return n;
  if (n === 0) return m;

  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1, // deletion
        dp[i][j - 1] + 1, // insertion
        dp[i - 1][j - 1] + cost // substitution
      );
    }
  }

  return dp[m][n];
}

/**
 * Returns normalized similarity score between 0.0 (completely distinct) and 1.0 (exact match)
 */
export function stringSimilarity(s1: string, s2: string): number {
  const str1 = normalizeNFC(s1).toLowerCase();
  const str2 = normalizeNFC(s2).toLowerCase();
  if (str1 === str2) return 1.0;
  const maxLen = Math.max(str1.length, str2.length);
  if (maxLen === 0) return 1.0;

  const dist = levenshteinDistance(str1, str2);
  return Math.max(0, 1 - dist / maxLen);
}

/**
 * Partial ratio: checks if subphrase of target matches query with high similarity
 */
export function partialRatio(query: string, target: string): number {
  const q = normalizeNFC(query).toLowerCase();
  const t = normalizeNFC(target).toLowerCase();
  if (!q || !t) return 0;
  if (t.includes(q)) return 1.0;

  // If query is smaller than target, slide window
  if (q.length <= t.length) {
    let maxSim = 0;
    const windowSize = q.length;
    for (let i = 0; i <= t.length - windowSize; i++) {
      const sub = t.substring(i, i + windowSize);
      const sim = stringSimilarity(q, sub);
      if (sim > maxSim) maxSim = sim;
      if (maxSim === 1.0) break;
    }
    return maxSim;
  } else {
    return stringSimilarity(q, t);
  }
}

/**
 * Find best fuzzy match for a query inside a sentence/line, returning score and character offsets
 */
export function findBestSubMatch(
  query: string,
  lineText: string,
  minThreshold = 0.65
): { found: boolean; similarity: number; matchIndices: [number, number]; matchedWord: string } {
  const qNorm = normalizeNFC(query).toLowerCase();
  const lineNorm = normalizeNFC(lineText);
  const lineLower = lineNorm.toLowerCase();

  // 1. Direct exact substring search
  const directIdx = lineLower.indexOf(qNorm);
  if (directIdx !== -1) {
    return {
      found: true,
      similarity: 1.0,
      matchIndices: [directIdx, directIdx + qNorm.length],
      matchedWord: lineNorm.substring(directIdx, directIdx + qNorm.length),
    };
  }

  // 2. Tokenized word-level fuzzy matching
  const words = lineNorm.split(/\s+/);
  let currentOffset = 0;
  let bestSim = 0;
  let bestIndices: [number, number] = [0, 0];
  let bestWord = '';

  for (const word of words) {
    const wordIndex = lineNorm.indexOf(word, currentOffset);
    currentOffset = wordIndex !== -1 ? wordIndex + word.length : currentOffset;

    // strip punctuation for comparison
    const cleanWord = word.replace(/[.,/#!$%^&*;:{}=\-_`~()?"'<>]/g, '');
    const sim = stringSimilarity(qNorm, cleanWord);

    if (sim > bestSim) {
      bestSim = sim;
      bestWord = word;
      bestIndices = [wordIndex !== -1 ? wordIndex : 0, (wordIndex !== -1 ? wordIndex : 0) + word.length];
    }
  }

  // 3. Multi-word sliding window if query has multiple words
  const queryTokens = qNorm.split(/\s+/);
  if (queryTokens.length > 1 && words.length >= queryTokens.length) {
    const k = queryTokens.length;
    for (let i = 0; i <= words.length - k; i++) {
      const windowPhrase = words.slice(i, i + k).join(' ');
      const sim = stringSimilarity(qNorm, windowPhrase);
      if (sim > bestSim) {
        bestSim = sim;
        bestWord = windowPhrase;
        const phraseIdx = lineNorm.indexOf(windowPhrase);
        bestIndices = [phraseIdx, phraseIdx + windowPhrase.length];
      }
    }
  }

  if (bestSim >= minThreshold) {
    return {
      found: true,
      similarity: Number(bestSim.toFixed(3)),
      matchIndices: bestIndices,
      matchedWord: bestWord,
    };
  }

  return {
    found: false,
    similarity: Number(bestSim.toFixed(3)),
    matchIndices: [0, 0],
    matchedWord: '',
  };
}
