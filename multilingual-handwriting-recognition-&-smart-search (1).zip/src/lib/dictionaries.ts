/**
 * Per-language dictionaries and spell-checker engine for HTR post-processing
 * Covers: English, Tamil, Hindi (Devanagari), Malayalam
 */

import { levenshteinDistance, stringSimilarity } from './fuzzyMatcher';
import { normalizeNFC } from './unicodeUtils';

export const DICTIONARIES: Record<string, string[]> = {
  en: [
    'the', 'quick', 'brown', 'fox', 'jumps', 'over', 'lazy', 'dog', 'handwriting', 'recognition',
    'multilingual', 'neural', 'network', 'machine', 'learning', 'deep', 'recurrent', 'bidirectional',
    'connectionist', 'temporal', 'classification', 'accuracy', 'dataset', 'segmentation', 'bounding',
    'document', 'transcription', 'cursive', 'manuscript', 'confidence', 'indexer', 'summarization',
    'report', 'medical', 'historical', 'evaluation', 'training', 'validation', 'features', 'algorithm',
    'language', 'processing', 'information', 'retrieval', 'similarity', 'character', 'vocabulary',
  ],
  ta: [
    'வணக்கம்', 'தமிழ்', 'எங்கள்', 'மொழி', 'கல்வி', 'சிறந்த', 'தமிழ்நாடு', 'பாரதி', 'திருக்குறள்',
    'அறம்', 'பொருள்', 'இன்பம்', 'வீடு', 'கையெழுத்து', 'அறிதல்', 'பகுப்பாய்வு', 'ஆவணம்', 'வரலாறு',
    'சுவடி', 'பண்டைய', 'கலை', 'இலக்கியம்', 'சொற்கள்', 'வாக்கியம்', 'சுருக்கம்', 'தேடல்', 'நூல்',
    'புத்தகம்', 'பயிற்சி', 'மாதிரி', 'அகராதி', 'தமிழ்மொழி', 'உரை', 'எழுத்துக்கள்', 'பரிசோதனை',
  ],
  hi: [
    'नमस्ते', 'भारत', 'हस्तलेख', 'पहचान', 'भाषा', 'देवनागरी', 'विद्या', 'विनय', 'परिश्रम', 'सफलता',
    'कुंजी', 'ज्ञान', 'विज्ञान', 'दस्तावेज', 'पांडुलिपि', 'शब्दकोश', 'वाक्य', 'सारांश', 'खोज',
    'इतिहास', 'साहित्य', 'पुस्तक', 'मॉडल', 'सटीकता', 'अक्षर', 'वर्णमाला', 'कंप्यूटर', 'प्रणाली',
    'परीक्षण', 'प्रशिक्षण', 'संस्कृत', 'हिंदी', 'अध्ययन', 'अनुसंधान',
  ],
  ml: [
    'നമസ്കാരം', 'മലയാളം', 'നമ്മുടെ', 'മാതൃഭാഷ', 'കേരളം', 'ദൈവത്തിന്റെ', 'സ്വന്തം', 'നാട്',
    'കയ്യെഴുത്ത്', 'തിരിച്ചറിയൽ', 'ഭാഷ', 'സാഹിത്യം', 'രേഖ', 'താളിയോല', 'ചരിത്രം', 'വാക്കുകൾ',
    'സംഗ്രഹം', 'തിരച്ചിൽ', 'വിജ്ഞാനം', 'അക്ഷരമാല', 'മാതൃക', 'കൃത്യത', 'പരിശീലനം', 'ഗ്രന്ഥം',
    'വിദ്യാലയം', 'പഠനം', 'കവിത', 'ഗദ്യം', 'മലയാളഭാഷ',
  ],
};

export function suggestCorrection(
  word: string,
  lang: 'en' | 'ta' | 'hi' | 'ml'
): { original: string; suggestion: string | null; confidenceBoost: number } {
  const norm = normalizeNFC(word).toLowerCase();
  const clean = norm.replace(/[.,/#!$%^&*;:{}=\-_`~()?"'<>]/g, '');
  if (!clean || clean.length < 2) {
    return { original: word, suggestion: null, confidenceBoost: 0 };
  }

  const dict = DICTIONARIES[lang] || DICTIONARIES.en;

  // Exact match
  if (dict.includes(clean)) {
    return { original: word, suggestion: clean, confidenceBoost: 0.15 };
  }

  // Fuzzy match closest word in dictionary
  let bestWord: string | null = null;
  let maxSim = 0;

  for (const dictWord of dict) {
    const sim = stringSimilarity(clean, dictWord);
    if (sim > maxSim) {
      maxSim = sim;
      bestWord = dictWord;
    }
  }

  // If similarity is high (e.g. 1 character difference / OCR noise)
  if (bestWord && maxSim >= 0.72) {
    return {
      original: word,
      suggestion: bestWord,
      confidenceBoost: Number((maxSim * 0.2).toFixed(2)),
    };
  }

  return { original: word, suggestion: null, confidenceBoost: 0 };
}
