/**
 * TextRank Graph-based Extractive Summarizer
 * Multilingual support: English, Tamil, Hindi, Malayalam
 */

import { normalizeNFC } from './unicodeUtils';

// Multilingual common stopwords
const STOPWORDS: Record<string, Set<string>> = {
  en: new Set([
    'the', 'is', 'at', 'which', 'on', 'and', 'a', 'an', 'in', 'to', 'for', 'of', 'with', 'as', 'by',
    'this', 'that', 'it', 'from', 'or', 'are', 'was', 'were', 'be', 'been', 'has', 'have', 'had',
    'but', 'not', 'they', 'we', 'you', 'he', 'she', 'his', 'her', 'their', 'our', 'what', 'who',
  ]),
  ta: new Set([
    'மற்றும்', 'ஒரு', 'இந்த', 'அந்த', 'என்று', 'ஆகிய', 'உள்ள', 'கொண்டு', 'இருந்து', 'அவர்',
    'அவர்கள்', 'ஆனால்', 'என', 'அல்லது', 'நாம்', 'நீ', 'அவன்', 'அவள்', 'இல்லை', 'கூட', 'முதல்',
  ]),
  hi: new Set([
    'और', 'है', 'यह', 'वह', 'के', 'का', 'की', 'को', 'में', 'से', 'पर', 'ने', 'होता', 'होती',
    'था', 'थे', 'थी', 'एक', 'भी', 'लिए', 'कर', 'दिया', 'गया', 'इस', 'उस', 'हम', 'आप', 'वे',
  ]),
  ml: new Set([
    'കൂടി', 'എന്നാൽ', 'ഒരു', 'ഈ', 'ആ', 'എന്ന്', 'ഉള്ള', 'നിന്ന്', 'അവർ', 'നാം', 'എന്നീ',
    'ആണ്', 'ഉണ്ട്', 'ചെയ്തു', 'അത്', 'ഇത്', 'പക്ഷേ', 'പോലും', 'മാത്രം', 'തന്നെ',
  ]),
};

function tokenizeWords(sentence: string, lang = 'en'): string[] {
  const normalized = normalizeNFC(sentence).toLowerCase();
  const words = normalized.split(/[\s,.;:!?()[\]{}"'\\/।॥-]+/).filter((w) => w.length > 1);
  const stopSet = STOPWORDS[lang] || STOPWORDS.en;
  return words.filter((w) => !stopSet.has(w));
}

function sentenceSimilarity(words1: string[], words2: string[]): number {
  if (words1.length === 0 || words2.length === 0) return 0;
  const set2 = new Set(words2);
  let overlap = 0;
  for (const w of words1) {
    if (set2.has(w)) overlap++;
  }
  const denominator = Math.log(words1.length + 1) + Math.log(words2.length + 1);
  if (denominator === 0) return 0;
  return overlap / denominator;
}

export function extractSentences(text: string): string[] {
  const normalized = normalizeNFC(text);
  // Split on periods, newlines, Indic purna viram (। U+0964), question marks, exclamation marks
  const rawSentences = normalized
    .split(/(?<=[.!?।॥\n])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 5);

  return rawSentences;
}

export function runTextRank(
  text: string,
  lang: 'en' | 'ta' | 'hi' | 'ml' = 'en',
  ratio = 0.4,
  maxSentences = 4
): {
  summary: string;
  bullets: string[];
  keyEntities: string[];
  compressionRatio: number;
  rawWordCount: number;
  summaryWordCount: number;
} {
  const sentences = extractSentences(text);
  const rawWords = text.trim().split(/\s+/).filter(Boolean);
  const rawWordCount = rawWords.length;

  if (sentences.length === 0) {
    return {
      summary: text,
      bullets: [text],
      keyEntities: [],
      compressionRatio: 1.0,
      rawWordCount,
      summaryWordCount: rawWordCount,
    };
  }

  if (sentences.length <= 2) {
    return {
      summary: sentences.join(' '),
      bullets: sentences,
      keyEntities: extractTopKeywords(text, lang, 4),
      compressionRatio: 1.0,
      rawWordCount,
      summaryWordCount: rawWordCount,
    };
  }

  const tokenizedSentences = sentences.map((s) => tokenizeWords(s, lang));
  const n = sentences.length;

  // Build Adjacency Graph Matrix
  const weights: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  const degree: number[] = Array(n).fill(0);

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i !== j) {
        const sim = sentenceSimilarity(tokenizedSentences[i], tokenizedSentences[j]);
        weights[i][j] = sim;
        degree[i] += sim;
      }
    }
  }

  // PageRank iterative solver
  let scores: number[] = Array(n).fill(1 / n);
  const damping = 0.85;
  const maxIterations = 30;
  const epsilon = 0.0001;

  for (let iter = 0; iter < maxIterations; iter++) {
    const nextScores = Array(n).fill((1 - damping) / n);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        if (i !== j && degree[j] > 0) {
          nextScores[i] += damping * (weights[j][i] / degree[j]) * scores[j];
        }
      }
    }

    // Position prior boost (lead sentences usually carry high saliency in documents)
    if (n > 1) {
      nextScores[0] *= 1.15;
    }

    let diff = 0;
    for (let i = 0; i < n; i++) {
      diff += Math.abs(nextScores[i] - scores[i]);
    }
    scores = nextScores;
    if (diff < epsilon) break;
  }

  // Rank sentences
  const rankedIndices = sentences.map((_, i) => i).sort((a, b) => scores[b] - scores[a]);

  const targetCount = Math.max(1, Math.min(maxSentences, Math.ceil(n * ratio)));
  const selectedIndices = rankedIndices.slice(0, targetCount).sort((a, b) => a - b);

  const selectedSentences = selectedIndices.map((i) => sentences[i]);
  const summary = selectedSentences.join(' ');
  const summaryWords = summary.split(/\s+/).filter(Boolean);
  const summaryWordCount = summaryWords.length;
  const compressionRatio = rawWordCount > 0 ? Number((summaryWordCount / rawWordCount).toFixed(2)) : 1.0;

  return {
    summary,
    bullets: selectedSentences,
    keyEntities: extractTopKeywords(text, lang, 5),
    compressionRatio,
    rawWordCount,
    summaryWordCount,
  };
}

export function extractTopKeywords(text: string, lang = 'en', count = 5): string[] {
  const words = tokenizeWords(text, lang);
  const freq: Record<string, number> = {};
  for (const w of words) {
    if (w.length < 3) continue;
    freq[w] = (freq[w] || 0) + 1;
  }
  return Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, count)
    .map(([w]) => w);
}
