import React, { useState, useRef } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  X,
  Target,
  Wand2,
} from 'lucide-react';
import { DocumentResult, WordPrediction, BoundingBox } from '../types/htr';

interface DocumentViewerProps {
  document: DocumentResult;
  selectedLineId: string | null;
  selectedWordId: string | null;
  onSelectLine: (lineId: string) => void;
  onSelectWord: (wordId: string, lineId: string) => void;
  highlightBoxes?: BoundingBox[];
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  document,
  selectedLineId,
  selectedWordId,
  onSelectLine,
  onSelectWord,
  highlightBoxes = [],
}) => {
  const [zoom, setZoom] = useState(1);
  const [showBoxes, setShowBoxes] = useState(true);
  const [showWords, setShowWords] = useState(true);
  const [showConfidenceColors, setShowConfidenceColors] = useState(true);
  const [hoveredWord, setHoveredWord] = useState<WordPrediction | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 0.25, 2.5));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 0.25, 0.6));
  const handleResetZoom = () => setZoom(1);

  // Confidence color mapper
  const getConfidenceColor = (conf: number, isSelected: boolean) => {
    if (isSelected) {
      return 'border-indigo-400 bg-indigo-500/30 ring-4 ring-indigo-400/90 shadow-xl z-30';
    }
    if (!showConfidenceColors) {
      return 'border-blue-400/60 bg-blue-500/10 hover:border-blue-300 z-10';
    }
    if (conf >= 0.9) {
      return 'border-emerald-400/70 bg-emerald-500/15 hover:border-emerald-300 hover:bg-emerald-500/25 z-10';
    }
    if (conf >= 0.75) {
      return 'border-amber-400/80 bg-amber-500/15 hover:border-amber-300 hover:bg-amber-500/25 z-10';
    }
    return 'border-rose-400/80 bg-rose-500/20 hover:border-rose-300 hover:bg-rose-500/30 z-10';
  };

  // Find exact selected word object
  const selectedWord = document.lines
    .flatMap((l) => l.words)
    .find((w) => w.id === selectedWordId) || null;

  // Active word in inspector: prioritize hovered if currently hovering, otherwise selected
  const activeInspectorWord = hoveredWord || selectedWord;

  // Find which line contains the active inspector word
  const activeLine = activeInspectorWord
    ? document.lines.find((l) => l.words.some((w) => w.id === activeInspectorWord.id))
    : null;

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden flex flex-col h-full shadow-xl">
      {/* Canvas Toolbar */}
      <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span className="text-xs font-semibold text-white">Visual Document Inspector</span>
          <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
            {document.lines.length} lines detected
          </span>
        </div>

        {/* Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowBoxes(!showBoxes)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
              showBoxes
                ? 'bg-indigo-600/30 border-indigo-500/50 text-indigo-200'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            Lines
          </button>
          <button
            onClick={() => setShowWords(!showWords)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
              showWords
                ? 'bg-indigo-600/30 border-indigo-500/50 text-indigo-200'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            Words
          </button>
          <button
            onClick={() => setShowConfidenceColors(!showConfidenceColors)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
              showConfidenceColors
                ? 'bg-emerald-600/30 border-emerald-500/50 text-emerald-200'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
            title="Color bounding boxes by OCR confidence level"
          >
            Confidence Map
          </button>

          {/* Zoom Controls */}
          <div className="flex items-center border border-slate-800 rounded-lg bg-slate-900 ml-2">
            <button
              onClick={handleZoomOut}
              className="p-1 hover:text-white text-slate-400"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] px-2 text-slate-300 font-mono">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={handleZoomIn}
              className="p-1 hover:text-white text-slate-400"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleResetZoom}
              className="p-1 hover:text-white text-slate-400 border-l border-slate-800"
              title="Reset Zoom"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Canvas Viewport */}
      <div
        ref={containerRef}
        className="relative flex-1 overflow-auto bg-slate-950 p-6 flex items-center justify-center min-h-[500px]"
      >
        <div
          style={{
            transform: `scale(${zoom})`,
            transformOrigin: 'top center',
            transition: 'transform 0.15s ease-out',
          }}
          className="relative inline-block shadow-2xl rounded-lg overflow-hidden border border-slate-700/60 select-none"
        >
          {/* Handwritten Document Image */}
          <img
            src={document.imageUrl}
            alt={document.name}
            className="max-w-full h-auto block rounded-lg pointer-events-none"
          />

          {/* Bounding Boxes Layer */}
          {showBoxes && (
            <div className="absolute inset-0 pointer-events-auto">
              {document.lines.map((line) => {
                const isLineSelected = selectedLineId === line.id;
                return (
                  <div key={line.id}>
                    {/* Line Bounding Box (Only border and label intercept clicks; interior lets word clicks pass through) */}
                    <div
                      style={{
                        top: `${line.bbox.ymin}%`,
                        left: `${line.bbox.xmin}%`,
                        height: `${line.bbox.ymax - line.bbox.ymin}%`,
                        width: `${line.bbox.xmax - line.bbox.xmin}%`,
                      }}
                      className={`absolute border rounded pointer-events-none transition-all ${
                        isLineSelected
                          ? 'border-indigo-500/60 bg-indigo-500/5'
                          : 'border-slate-400/20'
                      }`}
                    >
                      {/* Clickable Line Label */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectLine(line.id);
                        }}
                        className="pointer-events-auto absolute -top-3.5 left-0 text-[9px] font-mono px-1 rounded bg-slate-900/90 text-slate-300 hover:text-white border border-slate-700 hover:border-indigo-400 transition-all cursor-pointer"
                      >
                        L{line.lineNumber} • {Math.round(line.confidence * 100)}%
                      </button>
                    </div>

                    {/* Word Bounding Boxes inside line - HIGHEST CLICK PRIORITY */}
                    {showWords &&
                      line.words.map((word) => {
                        const isWordSelected = selectedWordId === word.id;
                        return (
                          <div
                            key={word.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectWord(word.id, line.id);
                              setHoveredWord(word);
                            }}
                            onTouchStart={(e) => {
                              e.stopPropagation();
                              onSelectWord(word.id, line.id);
                              setHoveredWord(word);
                            }}
                            onMouseEnter={() => setHoveredWord(word)}
                            onMouseLeave={() => setHoveredWord(null)}
                            style={{
                              top: `${word.bbox.ymin}%`,
                              left: `${word.bbox.xmin}%`,
                              height: `${word.bbox.ymax - word.bbox.ymin}%`,
                              width: `${word.bbox.xmax - word.bbox.xmin}%`,
                            }}
                            className={`absolute border rounded cursor-pointer pointer-events-auto transition-all ${getConfidenceColor(
                              word.confidence,
                              isWordSelected
                            )}`}
                          >
                            {/* Floating Label directly over the selected/touched word */}
                            {isWordSelected && (
                              <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-indigo-600 text-white font-bold text-xs px-2 py-0.5 rounded shadow-xl pointer-events-none whitespace-nowrap z-50 border border-indigo-300/80 ring-2 ring-indigo-500/50 flex items-center gap-1 font-sans animate-in fade-in zoom-in-95">
                                <span>{word.text}</span>
                                <span className="text-[10px] text-indigo-200 font-mono">
                                  ({Math.round(word.confidence * 100)}%)
                                </span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                  </div>
                );
              })}

              {/* Search Highlight Overlays */}
              {highlightBoxes.map((box, bIdx) => (
                <div
                  key={`hl-${bIdx}`}
                  style={{
                    top: `${box.ymin}%`,
                    left: `${box.xmin}%`,
                    height: `${box.ymax - box.ymin}%`,
                    width: `${box.xmax - box.xmin}%`,
                  }}
                  className="absolute border-2 border-amber-400 bg-amber-400/30 rounded ring-4 ring-amber-400/40 animate-pulse pointer-events-none z-20"
                />
              ))}
            </div>
          )}
        </div>

        {/* Word Inspector Card (Shows for touched/clicked word OR hovered word) */}
        {activeInspectorWord && (
          <div className="absolute bottom-4 left-4 z-40 bg-slate-900/95 border border-indigo-500/50 rounded-2xl p-4 shadow-2xl backdrop-blur-md max-w-sm w-full animate-in fade-in slide-in-from-bottom-2">
            <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  {selectedWord?.id === activeInspectorWord.id ? 'Selected Word' : 'Hovered Word'}
                </span>
                {activeLine && (
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.2 rounded">
                    Line {activeLine.lineNumber}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    activeInspectorWord.confidence >= 0.9
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : activeInspectorWord.confidence >= 0.75
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {Math.round(activeInspectorWord.confidence * 100)}% Confidence
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setHoveredWord(null);
                  }}
                  className="text-slate-400 hover:text-white p-0.5 rounded"
                  title="Dismiss Inspector"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Word Display in Native Font */}
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 mb-2">
              <span className="text-[10px] text-slate-400 block mb-0.5">Transcribed Text:</span>
              <p className="text-lg font-bold text-white tracking-wide font-sans break-all">
                "{activeInspectorWord.text}"
              </p>
            </div>

            {/* Dictionary & Spell-check */}
            {activeInspectorWord.suggestedCorrection && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-2 mb-2 flex items-center justify-between text-xs">
                <span className="text-amber-300 flex items-center gap-1">
                  <Wand2 className="w-3 h-3" />
                  <span>Suggestion:</span>
                  <strong className="underline ml-0.5">{activeInspectorWord.suggestedCorrection}</strong>
                </span>
                <span className="text-[10px] text-amber-400 font-mono">Lexicon match</span>
              </div>
            )}

            {/* CTC Beam Alternatives */}
            {activeInspectorWord.alternatives && activeInspectorWord.alternatives.length > 0 && (
              <div className="text-[11px] text-slate-400">
                <span className="text-slate-500">CTC Beam Alternatives:</span>{' '}
                <span className="font-mono text-slate-300">
                  {activeInspectorWord.alternatives.join(', ')}
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Legend Footer */}
      <div className="px-4 py-2 bg-slate-950/90 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/50 border border-emerald-400" />
            <span>&gt;90% Confident</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-500/50 border border-amber-400" />
            <span>75-90% Moderate</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-rose-500/50 border border-rose-400" />
            <span>&lt;75% Review</span>
          </span>
        </div>
        <span className="hidden sm:inline">Touch or click any word box to view in inspector</span>
      </div>
    </div>
  );
};
