import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Sliders,
  Copy,
  Download,
  Check,
  Filter,
  ArrowRight,
  Loader2,
  FileText,
  Tag,
  Zap,
} from 'lucide-react';
import { DocumentResult, SummaryResult, SupportedLanguage } from '../types/htr';
import { runTextRank } from '../lib/textRank';

interface SummarizerPanelProps {
  document: DocumentResult | null;
  documents: DocumentResult[];
  onSelectDocument: (doc: DocumentResult) => void;
}

export const SummarizerPanel: React.FC<SummarizerPanelProps> = ({
  document,
  documents,
  onSelectDocument,
}) => {
  const [mode, setMode] = useState<'extractive' | 'abstractive'>('extractive');
  const [maxSentences, setMaxSentences] = useState(3);
  const [filterLowConfidence, setFilterLowConfidence] = useState(true);
  const [confidenceCutoff, setConfidenceCutoff] = useState(0.75);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summaryResult, setSummaryResult] = useState<SummaryResult | null>(null);
  const [copied, setCopied] = useState(false);

  // Compute clean text based on low-confidence line filter
  const cleanDocumentText = (doc: DocumentResult): string => {
    if (!filterLowConfidence) return doc.fullText;
    const cleanLines = doc.lines
      .filter((l) => l.confidence >= confidenceCutoff)
      .map((l) => l.text);
    return cleanLines.join('\n');
  };

  const handleGenerateSummary = async () => {
    if (!document) return;
    setIsSummarizing(true);

    const sourceText = cleanDocumentText(document);

    try {
      const response = await fetch('/api/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: sourceText,
          language: document.detectedScript || 'en',
          mode,
          maxSentences,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setSummaryResult(data);
      } else {
        // Fallback to client-side TextRank
        const fallback = runTextRank(sourceText, document.detectedScript as any, 0.5, maxSentences);
        setSummaryResult({
          type: 'extractive',
          ...fallback,
          modelUsed: 'Local TextRank Graph Engine',
        });
      }
    } catch (err) {
      console.warn('API error, using local TextRank:', err);
      const fallback = runTextRank(sourceText, document.detectedScript as any, 0.5, maxSentences);
      setSummaryResult({
        type: 'extractive',
        ...fallback,
        modelUsed: 'Local TextRank Graph Engine',
      });
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleCopy = () => {
    if (!summaryResult) return;
    const textToCopy = `${summaryResult.summary}\n\nKey Takeaways:\n${summaryResult.bullets
      .map((b) => `• ${b}`)
      .join('\n')}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadMd = () => {
    if (!summaryResult || !document) return;
    const content = `# HTR Document Summary: ${document.name}
**Language:** ${document.detectedScript.toUpperCase()}
**Engine:** ${summaryResult.modelUsed}
**Word Compression:** ${summaryResult.rawWordCount} words → ${summaryResult.summaryWordCount} words (${Math.round((1 - summaryResult.compressionRatio) * 100)}% reduced)

## Summary
${summaryResult.summary}

## Key Takeaways
${summaryResult.bullets.map((b) => `- ${b}`).join('\n')}

## Entity Keywords
${summaryResult.keyEntities.map((k) => `\`${k}\``).join(' ')}
`;

    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${document.name.replace(/\.[^/.]+$/, '')}_summary.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header & Source Selection */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
                <BookOpen className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-white">Automatic Document Summarizer</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Extractive TextRank graph algorithm or Abstractive Multilingual AI for English, Tamil, Hindi, and Malayalam.
            </p>
          </div>

          {/* Document picker if multiple documents loaded */}
          {documents.length > 0 && (
            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-400">Target Document:</label>
              <select
                value={document?.id || ''}
                onChange={(e) => {
                  const found = documents.find((d) => d.id === e.target.value);
                  if (found) onSelectDocument(found);
                }}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-purple-500 font-medium max-w-xs truncate"
              >
                {documents.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.detectedScript.toUpperCase()})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Configuration Controls */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-2 border-t border-slate-800/80">
          {/* Method Selector */}
          <div className="md:col-span-4 bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
            <span className="text-xs text-slate-400 font-medium mb-2">Summarization Method:</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMode('extractive')}
                className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all flex flex-col items-center gap-1 ${
                  mode === 'extractive'
                    ? 'bg-purple-600/30 border-purple-500 text-purple-200 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>TextRank (Fast)</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('abstractive')}
                className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all flex flex-col items-center gap-1 ${
                  mode === 'abstractive'
                    ? 'bg-purple-600/30 border-purple-500 text-purple-200 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Abstractive AI</span>
              </button>
            </div>
          </div>

          {/* Sentence Count Slider */}
          <div className="md:col-span-4 bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-400 font-medium">Max Sentences:</span>
              <span className="font-mono font-bold text-purple-300">{maxSentences}</span>
            </div>
            <input
              type="range"
              min="1"
              max="6"
              value={maxSentences}
              onChange={(e) => setMaxSentences(parseInt(e.target.value, 10))}
              className="w-full accent-purple-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>Concise</span>
              <span>Detailed</span>
            </div>
          </div>

          {/* Noise Cleaner Toggle */}
          <div className="md:col-span-4 bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
                <Filter className="w-3 h-3 text-purple-400" />
                <span>Filter Low-Conf Lines:</span>
              </span>
              <input
                type="checkbox"
                checked={filterLowConfidence}
                onChange={(e) => setFilterLowConfidence(e.target.checked)}
                className="accent-purple-500 w-4 h-4 rounded cursor-pointer"
              />
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Excludes lines &lt; {Math.round(confidenceCutoff * 100)}% confidence to suppress OCR artifacts before generating summary.
            </p>
          </div>
        </div>

        {/* Generate Button */}
        <div className="mt-5 flex justify-end">
          <button
            onClick={handleGenerateSummary}
            disabled={!document || isSummarizing}
            className="px-6 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
          >
            {isSummarizing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Synthesizing Multilingual Summary...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Summary Now</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Summary Output Result */}
      {summaryResult && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6 animate-in fade-in">
          {/* Header & Metrics */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 uppercase tracking-wider">
                {summaryResult.type} Summary
              </span>
              <span className="text-xs text-slate-400">
                Engine: <span className="text-slate-200 font-medium">{summaryResult.modelUsed}</span>
              </span>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-xs text-slate-400">
                <span>Compression: </span>
                <span className="font-mono font-bold text-emerald-400">
                  {Math.round((1 - summaryResult.compressionRatio) * 100)}% shorter
                </span>
                <span className="text-[10px] text-slate-500 ml-1">
                  ({summaryResult.rawWordCount}w → {summaryResult.summaryWordCount}w)
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleCopy}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 transition-all"
                  title="Copy Summary"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={handleDownloadMd}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 transition-all"
                  title="Download Markdown Report"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Markdown</span>
                </button>
              </div>
            </div>
          </div>

          {/* Main Paragraph */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Executive Summary
            </h4>
            <p className="text-base text-slate-100 leading-relaxed font-sans bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
              {summaryResult.summary}
            </p>
          </div>

          {/* Bullet Points */}
          {summaryResult.bullets && summaryResult.bullets.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Key Extracted Takeaways
              </h4>
              <ul className="space-y-2">
                {summaryResult.bullets.map((bullet, bIdx) => (
                  <li
                    key={bIdx}
                    className="flex items-start gap-2.5 text-sm text-slate-200 bg-slate-950/40 p-3 rounded-lg border border-slate-800/60"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-2 flex-shrink-0" />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Entities / Keywords */}
          {summaryResult.keyEntities && summaryResult.keyEntities.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-800/80">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-purple-400" />
                <span>Salient Entity Keywords</span>
              </h4>
              <div className="flex flex-wrap gap-2">
                {summaryResult.keyEntities.map((ent, eIdx) => (
                  <span
                    key={eIdx}
                    className="px-2.5 py-1 rounded-md text-xs font-medium bg-slate-950 text-purple-300 border border-purple-500/20"
                  >
                    {ent}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
