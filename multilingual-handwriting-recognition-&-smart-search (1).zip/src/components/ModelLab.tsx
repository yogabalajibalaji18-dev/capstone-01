import React, { useState } from 'react';
import {
  Cpu,
  Layers,
  FileCode,
  BookOpen,
  Sparkles,
  BarChart3,
  CheckCircle,
  Database,
  ArrowRight,
  TrendingDown,
} from 'lucide-react';
import { LANGUAGE_METADATA } from '../data/charsets';
import { DICTIONARIES } from '../lib/dictionaries';
import { SupportedLanguage } from '../types/htr';

export const ModelLab: React.FC = () => {
  const [selectedLang, setSelectedLang] = useState<SupportedLanguage>('ta');
  const [searchChar, setSearchChar] = useState('');

  const meta = LANGUAGE_METADATA[selectedLang] || LANGUAGE_METADATA.ta;
  const dictWords = DICTIONARIES[selectedLang] || DICTIONARIES.en;

  const filteredChars = (meta.characters || []).filter((c) =>
    searchChar ? c.includes(searchChar) : true
  );

  return (
    <div className="space-y-6">
      {/* Top Overview Banner */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                <Cpu className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-white">HTR Neural Architecture & Charset Lab</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Deep CNN-BiLSTM-CTC recognizers and Unicode block character mappings for English, Tamil, Hindi, and Malayalam.
            </p>
          </div>

          {/* Script Picker */}
          <div className="flex items-center gap-2">
            {(['en', 'ta', 'hi', 'ml'] as SupportedLanguage[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLang(lang)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  selectedLang === lang
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
                }`}
              >
                {LANGUAGE_METADATA[lang].name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Network Architecture Diagram */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            <span>End-to-End Multilingual HTR Pipeline Topology</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">Input: (B, 1, 64, W) • Loss: CTC</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {/* Stage 1 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="w-6 h-6 rounded-md bg-blue-500/20 text-blue-400 flex items-center justify-center text-xs font-bold mb-2">
                1
              </div>
              <h4 className="text-xs font-bold text-slate-200">Preprocessing</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Otsu adaptive binarization, slant/skew correction, normalized height 64px.
              </p>
            </div>
            <span className="text-[10px] font-mono text-slate-500 mt-3 pt-2 border-t border-slate-800/80">
              Output: (1, 64, W)
            </span>
          </div>

          {/* Stage 2 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="w-6 h-6 rounded-md bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold mb-2">
                2
              </div>
              <h4 className="text-xs font-bold text-slate-200">CNN Backbone</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                7x Conv2D (3x3), BatchNorm, LeakyReLU, MaxPool. Feature extraction.
              </p>
            </div>
            <span className="text-[10px] font-mono text-slate-500 mt-3 pt-2 border-t border-slate-800/80">
              Shape: (512, 1, W/4)
            </span>
          </div>

          {/* Stage 3 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="w-6 h-6 rounded-md bg-pink-500/20 text-pink-400 flex items-center justify-center text-xs font-bold mb-2">
                3
              </div>
              <h4 className="text-xs font-bold text-slate-200">BiLSTM Recurrent</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                2x Bidirectional LSTM (256 units). Captures left/right cursive context.
              </p>
            </div>
            <span className="text-[10px] font-mono text-slate-500 mt-3 pt-2 border-t border-slate-800/80">
              Hidden: 512 dimensions
            </span>
          </div>

          {/* Stage 4 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="w-6 h-6 rounded-md bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold mb-2">
                4
              </div>
              <h4 className="text-xs font-bold text-slate-200">CTC Projection</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Linear dense projection to {meta.totalChars} character classes + blank token.
              </p>
            </div>
            <span className="text-[10px] font-mono text-slate-500 mt-3 pt-2 border-t border-slate-800/80">
              Softmax: ({meta.totalChars + 1}) classes
            </span>
          </div>

          {/* Stage 5 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="w-6 h-6 rounded-md bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs font-bold mb-2">
                5
              </div>
              <h4 className="text-xs font-bold text-slate-200">Beam Search + LM</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                CTC beam decoding with language model scoring & Unicode NFC composition.
              </p>
            </div>
            <span className="text-[10px] font-mono text-slate-500 mt-3 pt-2 border-t border-slate-800/80">
              Output: Unicode String
            </span>
          </div>
        </div>
      </div>

      {/* Model Spec & Charset Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Model Specs & Metrics */}
        <div className="lg:col-span-5 bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">{meta.name} Recognizer</h3>
              <p className="text-xs text-slate-400">{meta.modelPath}</p>
            </div>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {meta.totalChars} Tokens
            </span>
          </div>

          {/* Benchmark Metrics */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Validation Benchmarks
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Character Error Rate (CER)</span>
                <p className="text-xl font-bold text-emerald-400 font-mono mt-1">4.8%</p>
                <span className="text-[10px] text-slate-500">Validation split (IAM / Indic)</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Word Error Rate (WER)</span>
                <p className="text-xl font-bold text-indigo-400 font-mono mt-1">11.2%</p>
                <span className="text-[10px] text-slate-500">With 3-gram language model</span>
              </div>
            </div>
          </div>

          {/* Unicode Block Details */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Unicode Specification
            </h4>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs space-y-1">
              <p className="text-slate-300">
                <span className="text-slate-500">Range:</span>{' '}
                <span className="font-mono text-indigo-300">{meta.unicodeRange}</span>
              </p>
              <p className="text-slate-300">
                <span className="text-slate-500">Vowels Count:</span> {meta.vowels.length}
              </p>
              <p className="text-slate-300">
                <span className="text-slate-500">Consonants Count:</span> {meta.consonants.length}
              </p>
              <p className="text-slate-300">
                <span className="text-slate-500">Sample Phrase:</span>{' '}
                <span className="italic text-slate-200">"{meta.samplePhrase}"</span>
              </p>
            </div>
          </div>

          {/* Dictionary stats */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Lexicon Spell-Checker Vocabulary</span>
              <span className="text-[11px] font-mono text-slate-500">{dictWords.length} words</span>
            </h4>
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto bg-slate-950 p-3 rounded-xl border border-slate-800">
              {dictWords.slice(0, 30).map((w, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded text-[11px] bg-slate-900 text-slate-300 border border-slate-800"
                >
                  {w}
                </span>
              ))}
              {dictWords.length > 30 && (
                <span className="text-[10px] text-slate-500 self-center">
                  +{dictWords.length - 30} more
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right: Character Set Grid */}
        <div className="lg:col-span-7 bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-white">
                {meta.name} Charset Matrix ({filteredChars.length} characters)
              </h3>
              <p className="text-xs text-slate-400">
                Corresponds to <code className="font-mono text-indigo-300">config/charsets/charset_{selectedLang}.txt</code>
              </p>
            </div>
            <input
              type="text"
              value={searchChar}
              onChange={(e) => setSearchChar(e.target.value)}
              placeholder="Search glyph..."
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 w-36"
            />
          </div>

          {/* Vowels Row */}
          {meta.vowels.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-indigo-400 uppercase tracking-wider">
                Vowels / Independent Glyphs ({meta.vowels.length})
              </span>
              <div className="flex flex-wrap gap-1.5">
                {meta.vowels.map((v, i) => (
                  <div
                    key={i}
                    className="w-9 h-9 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-base font-semibold text-slate-200 hover:border-indigo-400 hover:text-white transition-all cursor-pointer shadow-sm"
                    title={`Unicode: U+${v.charCodeAt(0).toString(16).toUpperCase()}`}
                  >
                    {v}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Consonants Row */}
          {meta.consonants.length > 0 && (
            <div className="space-y-1.5 pt-2 border-t border-slate-800">
              <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider">
                Consonants ({meta.consonants.length})
              </span>
              <div className="flex flex-wrap gap-1.5">
                {meta.consonants.map((c, i) => (
                  <div
                    key={i}
                    className="w-9 h-9 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-base font-semibold text-slate-200 hover:border-purple-400 hover:text-white transition-all cursor-pointer shadow-sm"
                    title={`Unicode: U+${c.charCodeAt(0).toString(16).toUpperCase()}`}
                  >
                    {c}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* All Characters & Diacritics Grid */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Complete Character Set & Diacritics ({filteredChars.length})
            </span>
            <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 gap-2 max-h-72 overflow-y-auto p-1">
              {filteredChars.map((char, cIdx) => (
                <div
                  key={cIdx}
                  className="aspect-square rounded-lg bg-slate-950 border border-slate-800 flex flex-col items-center justify-center hover:border-indigo-500 hover:bg-slate-800/80 transition-all cursor-pointer group p-1"
                >
                  <span className="text-base font-semibold text-slate-200 group-hover:text-white group-hover:scale-110 transition-transform">
                    {char}
                  </span>
                  <span className="text-[8px] font-mono text-slate-500 group-hover:text-indigo-300">
                    U+{char.charCodeAt(0).toString(16).toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
