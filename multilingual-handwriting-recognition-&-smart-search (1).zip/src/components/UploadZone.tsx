import React, { useRef, useState } from 'react';
import {
  Upload,
  Camera,
  Languages,
  Sparkles,
  FileImage,
  ArrowRight,
  Loader2,
  CheckCircle,
} from 'lucide-react';
import { SupportedLanguage } from '../types/htr';
import { SAMPLE_DOCUMENTS, generateHandwrittenCanvas, SampleDocument } from '../data/samples';

interface UploadZoneProps {
  onProcessImage: (imageBase64: string, language: SupportedLanguage, fileName: string) => Promise<void>;
  onSelectPresetSample?: (sample: SampleDocument) => void;
  isProcessing: boolean;
  selectedLanguage: SupportedLanguage;
  setSelectedLanguage: (lang: SupportedLanguage) => void;
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  onProcessImage,
  onSelectPresetSample,
  isProcessing,
  selectedLanguage,
  setSelectedLanguage,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const base64 = uploadEvent.target?.result as string;
      if (base64) {
        onProcessImage(base64, selectedLanguage, file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSample = (sample: SampleDocument) => {
    setSelectedLanguage(sample.language);
    if (onSelectPresetSample) {
      onSelectPresetSample(sample);
    } else {
      const dataUrl = generateHandwrittenCanvas(sample);
      onProcessImage(dataUrl, sample.language, `${sample.id}.png`);
    }
  };

  const startCamera = async () => {
    try {
      setCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access failed:', err);
      alert('Unable to access camera. Please check camera permissions.');
      setCameraActive(false);
    }
  };

  const captureCamera = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1280;
    canvas.height = videoRef.current.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      stopCamera();
      onProcessImage(dataUrl, selectedLanguage, `camera_capture_${Date.now()}.png`);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Config Bar */}
      <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <span>Handwriting Ingestion</span>
            <span className="text-xs font-normal text-slate-400">
              (Multi-script Line Segmentation & CTC Recognizer)
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Upload handwritten notes, letters, palm leaves, or archival manuscripts in English, Tamil, Hindi, or Malayalam.
          </p>
        </div>

        {/* Script Selection Dropdown */}
        <div className="flex items-center gap-3">
          <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5 whitespace-nowrap">
            <Languages className="w-3.5 h-3.5 text-indigo-400" />
            <span>Target Script:</span>
          </label>
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value as SupportedLanguage)}
            className="bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
          >
            <option value="auto">✨ Auto-Detect Script (Classifier)</option>
            <option value="en">English (IAM / Latin)</option>
            <option value="ta">Tamil (தமிழ் • U+0B80)</option>
            <option value="hi">Hindi (देवनागरी • U+0900)</option>
            <option value="ml">Malayalam (മലയാളം • U+0D00)</option>
          </select>
        </div>
      </div>

      {/* Main Upload Dropzone / Camera Modal */}
      {cameraActive ? (
        <div className="bg-slate-900 border border-slate-700 rounded-2xl p-4 flex flex-col items-center gap-4">
          <div className="relative w-full max-w-2xl aspect-video bg-black rounded-xl overflow-hidden border border-slate-800">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <div className="absolute inset-0 border-2 border-dashed border-indigo-400/50 m-8 pointer-events-none rounded-lg" />
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={captureCamera}
              className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/30"
            >
              <Camera className="w-4 h-4" />
              Capture Document
            </button>
            <button
              onClick={stopCamera}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-medium"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all ${
            dragActive
              ? 'border-indigo-400 bg-indigo-950/20 scale-[1.01]'
              : 'border-slate-800 hover:border-slate-700 bg-slate-900/40 hover:bg-slate-900/70'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
          />

          <div className="flex flex-col items-center justify-center gap-3">
            <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shadow-inner">
              {isProcessing ? (
                <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
              ) : (
                <Upload className="w-8 h-8" />
              )}
            </div>

            <div>
              <p className="text-base font-semibold text-white">
                {isProcessing ? 'Recognizing Handwritten Text...' : 'Drop handwriting image here, or browse'}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Supports JPG, PNG, WebP up to 25MB • Ruled, unruled, cursive, or historical script documents
              </p>
            </div>

            {!isProcessing && (
              <div className="flex items-center gap-3 mt-2" onClick={(e) => e.stopPropagation()}>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all"
                >
                  Select File
                </button>
                <button
                  type="button"
                  onClick={startCamera}
                  className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-all"
                >
                  <Camera className="w-3.5 h-3.5 text-slate-400" />
                  Live Camera
                </button>
              </div>
            )}
          </div>

          {/* Processing Pipeline steps animation */}
          {isProcessing && (
            <div className="mt-6 pt-6 border-t border-slate-800/80 max-w-md mx-auto">
              <div className="grid grid-cols-4 gap-2 text-[10px] text-slate-400 font-medium text-center">
                <div className="flex flex-col items-center gap-1 text-indigo-300">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
                  <span>Binarize</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-indigo-300">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                  <span>Segments</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-indigo-300">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                  <span>CTC Beam</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-indigo-300">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                  <span>NFC Normalize</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Preset Realistic Multilingual Samples Library */}
      <div className="bg-slate-900/50 rounded-2xl p-5 border border-slate-800/90">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">
              Instant Sample Documents (Click to load & transcribe)
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">4 distinct languages configured</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SAMPLE_DOCUMENTS.map((sample) => (
            <button
              key={sample.id}
              disabled={isProcessing}
              onClick={() => handleSelectSample(sample)}
              className="group text-left p-3.5 rounded-xl bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800 hover:border-indigo-500/50 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                    {sample.language.toUpperCase()}
                  </span>
                  <span className="text-[10px] text-slate-400 truncate max-w-[120px]">
                    {sample.scriptBadge}
                  </span>
                </div>
                <h4 className="text-xs font-semibold text-slate-200 group-hover:text-white line-clamp-1">
                  {sample.title}
                </h4>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                  {sample.description}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-indigo-400 font-medium">
                <span>Transcribe Document</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
