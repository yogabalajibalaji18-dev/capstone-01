import React, { useState, useEffect } from 'react';
import {
  X,
  Play,
  CheckCircle2,
  XCircle,
  Clock,
  FlaskConical,
  RefreshCw,
  Terminal,
} from 'lucide-react';
import { SystemTestResult } from '../types/htr';
import { runAllTests } from '../lib/testRunner';

interface TestRunnerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TestRunnerModal: React.FC<TestRunnerModalProps> = ({ isOpen, onClose }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<SystemTestResult[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'unit' | 'integration'>('all');

  const executeTests = () => {
    setIsRunning(true);
    setTimeout(() => {
      const results = runAllTests();
      setTestResults(results);
      setIsRunning(false);
    }, 400);
  };

  useEffect(() => {
    if (isOpen && testResults.length === 0) {
      executeTests();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const totalTests = testResults.length;
  const passedTests = testResults.filter((t) => t.passed).length;
  const allPassed = totalTests > 0 && passedTests === totalTests;

  const filteredResults = testResults.filter(
    (t) => selectedCategory === 'all' || t.category === selectedCategory
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <FlaskConical className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">HTR Automated Test Suite</h3>
              <p className="text-xs text-slate-400">
                Unit & Integration tests (tests/unit/*, tests/integration/*)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats Summary Bar */}
        <div className="px-6 py-3 bg-slate-950/40 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-full border ${
                allPassed
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
              }`}
            >
              {allPassed ? 'ALL TESTS PASSED' : 'TESTS FAILED'}
            </span>
            <span className="text-xs text-slate-300">
              {passedTests} / {totalTests} Passed
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex rounded-lg border border-slate-800 bg-slate-950 p-0.5 text-xs">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-2 py-0.5 rounded ${
                  selectedCategory === 'all' ? 'bg-indigo-600 text-white' : 'text-slate-400'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedCategory('unit')}
                className={`px-2 py-0.5 rounded ${
                  selectedCategory === 'unit' ? 'bg-indigo-600 text-white' : 'text-slate-400'
                }`}
              >
                Unit
              </button>
              <button
                onClick={() => setSelectedCategory('integration')}
                className={`px-2 py-0.5 rounded ${
                  selectedCategory === 'integration' ? 'bg-indigo-600 text-white' : 'text-slate-400'
                }`}
              >
                Pipeline
              </button>
            </div>

            <button
              onClick={executeTests}
              disabled={isRunning}
              className="flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3 h-3 ${isRunning ? 'animate-spin' : ''}`} />
              <span>Rerun Suite</span>
            </button>
          </div>
        </div>

        {/* Tests List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {filteredResults.map((t, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex items-start justify-between gap-3"
            >
              <div className="flex items-start gap-3">
                {t.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-400 mt-0.5 flex-shrink-0" />
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-slate-200">{t.testName}</span>
                    <span className="text-[10px] uppercase font-semibold px-1.5 py-0.2 rounded bg-slate-900 text-slate-400 border border-slate-800">
                      {t.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{t.details}</p>
                </div>
              </div>

              <div className="flex items-center gap-1 text-[11px] font-mono text-slate-400 flex-shrink-0">
                <Clock className="w-3 h-3" />
                <span>{t.executionTimeMs}ms</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Continuous Integration / Automated HTR Verification</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
