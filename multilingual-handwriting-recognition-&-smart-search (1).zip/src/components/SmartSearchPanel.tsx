import React, { useState, useMemo } from 'react';
import {
  Search,
  Sliders,
  Sparkles,
  ArrowRight,
  FileText,
  Filter,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import { DocumentResult, SearchMatch, SupportedLanguage } from '../types/htr';
import { findBestSubMatch } from '../lib/fuzzyMatcher';
import { normalizeNFC } from '../lib/unicodeUtils';

interface SmartSearchPanelProps {
  documents: DocumentResult[];
  onSelectMatch: (match: SearchMatch) => void;
  initialQuery?: string;
}

export const SmartSearchPanel: React.FC<SmartSearchPanelProps> = ({
  documents,
  onSelectMatch,
  initialQuery = '',
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [fuzzyTolerance, setFuzzyTolerance] = useState(0.7);
  const [selectedLang, setSelectedLang] = useState<string>('all');

  // Suggested multi-lingual search queries
  const presetQueries = [
    { label: 'English: "recognition"', text: 'recognition' },
    { label: 'English (OCR error): "reecognition"', text: 'reecognition' },
    { label: 'Tamil: "தமிழ்" (Tamil)', text: 'தமிழ்' },
    { label: 'Tamil: "கல்வி" (Education)', text: 'கல்வி' },
    { label: 'Hindi: "सफलता" (Success)', text: 'सफलता' },
    { label: 'Hindi: "पांडुलिपि" (Manuscript)', text: 'पांडुलिपि' },
    { label: 'Malayalam: "മലയാളം" (Malayalam)', text: 'മലയാളം' },
    { label: 'Malayalam: "കേരളം" (Kerala)', text: 'കേരളം' },
  ];

  // Perform search
  const matches = useMemo(() => {
    const trimmed = normalizeNFC(query).trim();
    if (!trimmed) return [];

    const foundMatches: SearchMatch[] = [];

    for (const doc of documents) {
      if (selectedLang !== 'all' && doc.detectedScript !== selectedLang) {
        continue;
      }

      for (const line of doc.lines) {
        const match = findBestSubMatch(trimmed, line.text, fuzzyTolerance);
        if (match.found) {
          // Find matching word for bounding box if available
          let matchedWordObj = null;
          if (line.words) {
            matchedWordObj = line.words.find(
              (w) => findBestSubMatch(trimmed, w.text, fuzzyTolerance).found
            );
          }

          foundMatches.push({
            docId: doc.id,
            docName: doc.name,
            lineId: line.id,
            lineNumber: line.lineNumber,
            wordId: matchedWordObj?.id,
            lineText: line.text,
            matchedWord: match.matchedWord,
            similarity: match.similarity,
            bbox: matchedWordObj?.bbox || line.bbox,
            snippet: line.text,
            matchIndices: match.matchIndices,
          });
        }
      }
    }

    return foundMatches.sort((a, b) => b.similarity - a.similarity);
  }, [documents, query, fuzzyTolerance, selectedLang]);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                <Search className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-white">Smart Search & Word Spotter</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Multi-script keyword indexing with RapidFuzz similarity matching to tolerate OCR character misrecognitions.
            </p>
          </div>

          {/* Quick presets */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-slate-400">Try query:</span>
            {presetQueries.slice(0, 4).map((p, idx) => (
              <button
                key={idx}
                onClick={() => setQuery(p.text)}
                className="px-2 py-1 rounded-md text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all font-sans"
              >
                {p.text}
              </button>
            ))}
          </div>
        </div>

        {/* Search Inputs & Sliders */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search words in English, தமிழ், देवनागरी, or മലയാളം..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Fuzzy Tolerance Slider */}
          <div className="md:col-span-3 bg-slate-950/70 border border-slate-800 rounded-xl px-3.5 py-2 flex flex-col justify-center">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-400 flex items-center gap-1">
                <Sliders className="w-3 h-3 text-indigo-400" />
                <span>OCR Fuzzy Tolerance:</span>
              </span>
              <span className="font-mono font-bold text-indigo-300">
                {Math.round((1 - fuzzyTolerance) * 100)}%
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.0"
              step="0.05"
              value={fuzzyTolerance}
              onChange={(e) => setFuzzyTolerance(parseFloat(e.target.value))}
              className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Script Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value)}
              className="w-full h-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Scripts (Global Search)</option>
              <option value="en">English (Latin)</option>
              <option value="ta">Tamil (தமிழ்)</option>
              <option value="hi">Hindi (देवनागरी)</option>
              <option value="ml">Malayalam (മലയാളം)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Search Results Feed */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-white">Search Matches</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {matches.length} result{matches.length !== 1 ? 's' : ''}
            </span>
          </div>
          {query && (
            <span className="text-xs text-slate-400">
              Tolerance: {(fuzzyTolerance * 100).toFixed(0)}% minimum similarity
            </span>
          )}
        </div>

        {matches.length === 0 ? (
          <div className="p-12 text-center bg-slate-900/40 rounded-2xl border border-slate-800/80">
            <Search className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-sm text-slate-300 font-medium">
              {query ? 'No matching text found' : 'Enter a query to search across transcribed documents'}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Try adjusting the OCR fuzzy tolerance slider or selecting an example keyword above.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3">
            {matches.map((match, idx) => {
              // Highlight matched substring inside line snippet
              const prefix = match.lineText.substring(0, match.matchIndices[0]);
              const highlighted = match.lineText.substring(
                match.matchIndices[0],
                match.matchIndices[1]
              );
              const suffix = match.lineText.substring(match.matchIndices[1]);

              return (
                <div
                  key={`${match.docId}-${match.lineId}-${idx}`}
                  onClick={() => onSelectMatch(match)}
                  className="group p-4 bg-slate-900 hover:bg-slate-800/90 border border-slate-800 hover:border-indigo-500/50 rounded-xl transition-all cursor-pointer shadow flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                        {match.docName} • Line {match.lineNumber}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          match.similarity >= 0.95
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : match.similarity >= 0.8
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-indigo-500/20 text-indigo-300'
                        }`}
                      >
                        {(match.similarity * 100).toFixed(0)}% Similarity
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                        bbox: [{match.bbox.ymin}%, {match.bbox.xmin}%]
                      </span>
                    </div>

                    <p className="text-sm text-slate-200 leading-relaxed font-sans">
                      <span>{prefix}</span>
                      <mark className="bg-amber-400/30 text-amber-200 px-1 py-0.5 rounded border border-amber-400/50 font-semibold mx-0.5">
                        {highlighted || match.matchedWord}
                      </mark>
                      <span>{suffix}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 group-hover:text-indigo-300 whitespace-nowrap self-end md:self-center">
                    <span>Spot on Document</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
