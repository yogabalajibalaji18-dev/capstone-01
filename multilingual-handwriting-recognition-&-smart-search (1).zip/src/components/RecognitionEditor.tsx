import React, { useState } from 'react';
import {
  Copy,
  Download,
  Check,
  Edit3,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Search,
  BookOpen,
  Wand2,
  FileCode,
  Target,
  X,
} from 'lucide-react';
import { DocumentResult, LinePrediction, WordPrediction } from '../types/htr';
import { normalizeNFC } from '../lib/unicodeUtils';

interface RecognitionEditorProps {
  document: DocumentResult;
  selectedLineId: string | null;
  selectedWordId: string | null;
  onSelectLine: (lineId: string) => void;
  onSelectWord: (wordId: string, lineId: string) => void;
  onUpdateLineText: (lineId: string, newText: string) => void;
  onNavigateToSearch: (initialQuery?: string) => void;
  onNavigateToSummary: () => void;
}

export const RecognitionEditor: React.FC<RecognitionEditorProps> = ({
  document,
  selectedLineId,
  selectedWordId,
  onSelectLine,
  onSelectWord,
  onUpdateLineText,
  onNavigateToSearch,
  onNavigateToSummary,
}) => {
  const [copied, setCopied] = useState(false);
  const [editingLineId, setEditingLineId] = useState<string | null>(null);
  const [editTempText, setEditTempText] = useState('');

  const handleCopy = () => {
    navigator.clipboard.writeText(document.fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([document.fullText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${document.name.replace(/\.[^/.]+$/, '')}_transcription.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(document, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${document.name.replace(/\.[^/.]+$/, '')}_htr_results.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const startEdit = (line: LinePrediction) => {
    setEditingLineId(line.id);
    setEditTempText(line.text);
  };

  const saveEdit = (lineId: string) => {
    onUpdateLineText(lineId, normalizeNFC(editTempText));
    setEditingLineId(null);
  };

  const applyCorrection = (line: LinePrediction, word: WordPrediction, replacement: string) => {
    const updatedLine = line.text.replace(word.text, replacement);
    onUpdateLineText(line.id, normalizeNFC(updatedLine));
  };

  // Find currently selected word object & its line
  const selectedWordObj = document.lines
    .flatMap((l) => l.words)
    .find((w) => w.id === selectedWordId) || null;

  const selectedWordLine = selectedWordObj
    ? document.lines.find((l) => l.words.some((w) => w.id === selectedWordObj.id)) || null
    : null;

  // Language script display label
  const scriptBadgeMap: Record<string, { label: string; color: string }> = {
    en: { label: 'English (Latin)', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
    ta: { label: 'Tamil (தமிழ் • U+0B80)', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
    hi: { label: 'Hindi (देवनागरी • U+0900)', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
    ml: { label: 'Malayalam (മലയാളം • U+0D00)', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
  };

  const scriptInfo = scriptBadgeMap[document.detectedScript] || scriptBadgeMap.en;

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 flex flex-col h-full shadow-xl overflow-hidden">
      {/* Header & Meta */}
      <div className="p-4 bg-slate-950/80 border-b border-slate-800 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${scriptInfo.color}`}>
              {scriptInfo.label}
            </span>
            <span className="text-xs font-medium text-slate-300">
              Avg. Confidence: {(document.averageConfidence * 100).toFixed(1)}%
            </span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs flex items-center gap-1 transition-all cursor-pointer"
              title="Copy Full Text"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownloadTxt}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs flex items-center gap-1 transition-all cursor-pointer"
              title="Download UTF-8 TXT"
            >
              <Download className="w-3.5 h-3.5" />
              <span>TXT</span>
            </button>
            <button
              onClick={handleDownloadJson}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs flex items-center gap-1 transition-all cursor-pointer"
              title="Download JSON Bounding Boxes"
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>JSON</span>
            </button>
          </div>
        </div>

        {/* Quick Pipe actions */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() => onNavigateToSearch()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 border border-indigo-500/30 text-xs font-medium transition-all cursor-pointer"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Search in Document</span>
          </button>
          <button
            onClick={() => onNavigateToSummary()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 border border-purple-500/30 text-xs font-medium transition-all cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Generate Summary</span>
          </button>
        </div>
      </div>

      {/* Selected Word Inspector Card in Editor */}
      {selectedWordObj && (
        <div className="px-4 py-3 bg-indigo-950/30 border-b border-indigo-500/30 animate-in fade-in">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider">
                Touched Word Inspector
              </span>
              {selectedWordLine && (
                <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                  Line {selectedWordLine.lineNumber}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  selectedWordObj.confidence >= 0.9
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}
              >
                {(selectedWordObj.confidence * 100).toFixed(0)}% Confidence
              </span>
              <button
                onClick={() => onSelectWord('', '')}
                className="text-slate-400 hover:text-white p-0.5 rounded cursor-pointer"
                title="Deselect Word"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <div>
              <span className="text-[10px] text-slate-500 block">Exact Text:</span>
              <p className="text-lg font-bold text-white font-sans tracking-wide">
                "{selectedWordObj.text}"
              </p>
            </div>

            {selectedWordObj.suggestedCorrection && selectedWordLine && (
              <button
                onClick={() => {
                  applyCorrection(
                    selectedWordLine,
                    selectedWordObj,
                    selectedWordObj.suggestedCorrection!
                  );
                }}
                className="px-2.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>Apply: {selectedWordObj.suggestedCorrection}</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Line-by-Line Interactive Transcript */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[620px]">
        {document.lines.map((line) => {
          const isSelected = selectedLineId === line.id;
          const isEditing = editingLineId === line.id;

          return (
            <div
              key={line.id}
              onClick={() => onSelectLine(line.id)}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-slate-800/90 border-indigo-500/80 ring-1 ring-indigo-500/50 shadow-md'
                  : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-950'
              }`}
            >
              {/* Line Header */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                    Line {line.lineNumber}
                  </span>
                  <span
                    className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                      line.confidence >= 0.9
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : line.confidence >= 0.75
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-rose-500/20 text-rose-300'
                    }`}
                  >
                    {(line.confidence * 100).toFixed(0)}% Conf.
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      startEdit(line);
                    }}
                    className="p-1 hover:text-white text-slate-400 hover:bg-slate-800 rounded transition-all cursor-pointer"
                    title="Edit Line"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Text View / Inline Edit Mode */}
              {isEditing ? (
                <div className="space-y-2" onClick={(e) => e.stopPropagation()}>
                  <textarea
                    value={editTempText}
                    onChange={(e) => setEditTempText(e.target.value)}
                    rows={2}
                    className="w-full bg-slate-900 border border-indigo-500/80 rounded-lg p-2 text-sm text-white focus:outline-none font-medium"
                  />
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => setEditingLineId(null)}
                      className="px-2.5 py-1 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => saveEdit(line.id)}
                      className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
                    >
                      Save
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {/* Full line text formatted */}
                  <p className="text-sm font-medium text-slate-100 leading-relaxed font-sans">
                    {line.text}
                  </p>

                  {/* Word Pills with Interactive Touch & Click */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {line.words.map((word) => {
                      const isWordSelected = selectedWordId === word.id;
                      return (
                        <div
                          key={word.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectWord(word.id, line.id);
                          }}
                          onTouchStart={(e) => {
                            e.stopPropagation();
                            onSelectWord(word.id, line.id);
                          }}
                          className={`group relative text-xs px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                            isWordSelected
                              ? 'bg-indigo-600 text-white border-indigo-400 shadow-md ring-2 ring-indigo-400/50 font-bold'
                              : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <span>{word.text}</span>

                          {/* Quick dictionary spellcheck badge */}
                          {word.suggestedCorrection && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                applyCorrection(line, word, word.suggestedCorrection!);
                              }}
                              className="ml-1 text-[9px] text-amber-300 hover:underline inline-flex items-center gap-0.5"
                              title={`Apply suggestion: ${word.suggestedCorrection}`}
                            >
                              <Wand2 className="w-2.5 h-2.5" />
                              <span>{word.suggestedCorrection}</span>
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
